import React from 'react';

const ManageAllOrders = () => {
    return (
        <div>
            <h1>Manage All Orders</h1>
        </div>
    );
};

export default ManageAllOrders;