import React from 'react';

const ManageProducts = () => {
    return (
        <div>
            <h1>Manage Products</h1>
        </div>
    );
};

export default ManageProducts;