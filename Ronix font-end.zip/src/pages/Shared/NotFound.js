import React from 'react';

const NotFound = () => {
    return (
        <div>
            <img src="https://xiaoyuew.com/img/outage/1.png" alt="" />
        </div>
    );
};

export default NotFound;